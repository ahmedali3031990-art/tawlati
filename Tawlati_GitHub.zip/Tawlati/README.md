# 📱 تطبيق طاولتي (Tawlati) - دليل الإعداد على AIDE

## هيكل المشروع الكامل

```
Tawlati/
├── build.gradle                          ← Gradle المشروع الرئيسي
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle                      ← تبعيات التطبيق
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/tawlati/app/
        │   ├── TawlatiApp.java           ← Application class
        │   ├── models/
        │   │   ├── TableModel.java       ← نموذج بيانات الطاولة
        │   │   ├── WaitingCustomer.java  ← نموذج قائمة الانتظار
        │   │   └── AppSettings.java      ← نموذج الإعدادات
        │   ├── database/
        │   │   ├── TawlatiDatabase.java  ← Room Database
        │   │   ├── TawlatiRepository.java
        │   │   ├── TableDao.java
        │   │   ├── WaitingListDao.java
        │   │   └── SettingsDao.java
        │   ├── viewmodels/
        │   │   └── MainViewModel.java
        │   ├── adapters/
        │   │   ├── TableAdapter.java     ← عرض بطاقات الطاولات
        │   │   └── WaitingListAdapter.java
        │   ├── ui/
        │   │   ├── MainActivity.java     ← الشاشة الرئيسية
        │   │   ├── BookingActivity.java  ← شاشة الحجز
        │   │   ├── SettingsActivity.java ← الإعدادات
        │   │   └── WaitingListActivity.java
        │   └── utils/
        │       ├── NotificationHelper.java
        │       ├── AlarmHelper.java
        │       └── AlarmReceiver.java
        └── res/
            ├── layout/
            │   ├── activity_main.xml
            │   ├── activity_booking.xml
            │   ├── activity_settings.xml
            │   ├── activity_waiting_list.xml
            │   ├── item_table.xml
            │   └── item_waiting.xml
            ├── values/
            │   ├── colors.xml
            │   ├── strings.xml
            │   └── styles.xml
            └── drawable/
                ├── ic_coffee.xml
                ├── ic_home.xml
                ├── ic_people.xml
                ├── ic_add_booking.xml
                ├── ic_settings.xml
                ├── ic_table.xml
                ├── ic_calendar.xml
                ├── ic_queue.xml
                ├── ic_back.xml
                ├── ic_table_notification.xml
                ├── circle_primary.xml
                ├── circle_secondary.xml
                └── spinner_background.xml
```

---

## 🚀 خطوات الإعداد في AIDE

### 1. إنشاء المشروع في AIDE
- افتح AIDE → New Project → Android App (Gradle)
- اسم التطبيق: `Tawlati`
- Package name: `com.tawlati.app`
- احذف الملفات التلقائية واستبدلها بملفات هذا المشروع

### 2. نسخ الملفات بالترتيب الصحيح
انسخ الملفات بهذا الترتيب لتفادي الأخطاء:
1. `build.gradle` (app level) أولاً
2. ملفات `res/values/` (colors, strings, styles)
3. ملفات `res/drawable/`
4. ملفات `models/`
5. ملفات `database/`
6. ملفات `viewmodels/`
7. ملفات `adapters/`
8. ملفات `utils/`
9. ملفات `ui/`
10. `AndroidManifest.xml` أخيراً

### 3. إضافة Font (اختياري - لتحسين المظهر)
- في `res/` أنشئ مجلد `font`
- أضف ملف خط عربي مثل `cairo.ttf`
- أو احذف سطر `android:fontFamily="@font/cairo"` من `styles.xml`

---

## ⚙️ الميزات المطبقة

| الميزة | الحالة |
|--------|--------|
| عرض الطاولات بشبكة ديناميكية | ✅ |
| بطاقات الإحصاء (متاح/مشغول/انتظار) | ✅ |
| حجز الطاولات مع بيانات كاملة | ✅ |
| مؤقت تنازلي حي HH:MM:SS | ✅ |
| إشعارات قبل انتهاء الوقت | ✅ |
| إشعارات انتهاء الحجز | ✅ |
| قائمة انتظار FIFO | ✅ |
| اقتراح العميل التالي تلقائياً | ✅ |
| إعدادات محمية بكلمة مرور | ✅ |
| توليد الطاولات تلقائياً | ✅ |
| اتصال مباشر من الحجز | ✅ |
| Room Database محلي | ✅ |
| AlarmManager للإشعارات | ✅ |
| واجهة RTL عربية | ✅ |

---

## 🔑 بيانات الدخول الافتراضية
- كلمة مرور المدير: **1234**
- عدد الطاولات الافتراضي: 20 داخلية + 15 خارجية
- مدة الحجز الافتراضية: 60 دقيقة
- التنبيه قبل: 10 دقائق

---

## 📝 ملاحظات مهمة لـ AIDE
1. تأكد من إضافة إذن `CALL_PHONE` في الإعدادات يدوياً في الهاتف
2. في Android 13+ يجب قبول إذن الإشعارات عند أول تشغيل
3. إذا ظهر خطأ في `@font/cairo` احذف هذا السطر من styles.xml
4. تأكد من أن `minSdk` هو **26** في build.gradle
