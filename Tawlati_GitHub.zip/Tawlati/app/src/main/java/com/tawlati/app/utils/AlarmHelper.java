package com.tawlati.app.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.tawlati.app.models.TableModel;

public class AlarmHelper {

    public static final String ACTION_BOOKING_ALERT = "com.tawlati.BOOKING_ALERT";
    public static final String ACTION_BOOKING_EXPIRED = "com.tawlati.BOOKING_EXPIRED";
    public static final String EXTRA_TABLE_ID = "table_id";
    public static final String EXTRA_TABLE_NUMBER = "table_number";
    public static final String EXTRA_CUSTOMER_NAME = "customer_name";
    public static final String EXTRA_MINUTES_LEFT = "minutes_left";

    public static void scheduleBookingAlarms(Context context, TableModel table, int alertBeforeMinutes) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        // Schedule pre-end alert
        long preAlertTime = table.bookingEndTime - (alertBeforeMinutes * 60000L);
        if (preAlertTime > System.currentTimeMillis()) {
            Intent preAlertIntent = new Intent(context, AlarmReceiver.class);
            preAlertIntent.setAction(ACTION_BOOKING_ALERT);
            preAlertIntent.putExtra(EXTRA_TABLE_ID, table.id);
            preAlertIntent.putExtra(EXTRA_TABLE_NUMBER, table.tableNumber);
            preAlertIntent.putExtra(EXTRA_CUSTOMER_NAME, table.customerName);
            preAlertIntent.putExtra(EXTRA_MINUTES_LEFT, alertBeforeMinutes);

            PendingIntent preAlertPending = PendingIntent.getBroadcast(
                context, table.id * 10,
                preAlertIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            setExactAlarm(alarmManager, preAlertTime, preAlertPending);
        }

        // Schedule expiration alert
        Intent expiredIntent = new Intent(context, AlarmReceiver.class);
        expiredIntent.setAction(ACTION_BOOKING_EXPIRED);
        expiredIntent.putExtra(EXTRA_TABLE_ID, table.id);
        expiredIntent.putExtra(EXTRA_TABLE_NUMBER, table.tableNumber);
        expiredIntent.putExtra(EXTRA_CUSTOMER_NAME, table.customerName);

        PendingIntent expiredPending = PendingIntent.getBroadcast(
            context, table.id * 10 + 1,
            expiredIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        setExactAlarm(alarmManager, table.bookingEndTime, expiredPending);
    }

    public static void cancelBookingAlarms(Context context, int tableId) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        // Cancel pre-alert
        Intent preAlertIntent = new Intent(context, AlarmReceiver.class);
        preAlertIntent.setAction(ACTION_BOOKING_ALERT);
        PendingIntent preAlertPending = PendingIntent.getBroadcast(
            context, tableId * 10,
            preAlertIntent,
            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
        if (preAlertPending != null) {
            alarmManager.cancel(preAlertPending);
            preAlertPending.cancel();
        }

        // Cancel expired alert
        Intent expiredIntent = new Intent(context, AlarmReceiver.class);
        expiredIntent.setAction(ACTION_BOOKING_EXPIRED);
        PendingIntent expiredPending = PendingIntent.getBroadcast(
            context, tableId * 10 + 1,
            expiredIntent,
            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
        if (expiredPending != null) {
            alarmManager.cancel(expiredPending);
            expiredPending.cancel();
        }
    }

    private static void setExactAlarm(AlarmManager am, long triggerTime, PendingIntent pi) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pi);
        }
    }
}
