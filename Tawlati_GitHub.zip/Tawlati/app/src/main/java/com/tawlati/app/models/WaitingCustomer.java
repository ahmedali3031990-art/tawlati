package com.tawlati.app.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "waiting_list")
public class WaitingCustomer {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String customerName;
    public String customerPhone;
    public int guestsCount;
    public String preferredArea;   // "indoor" | "outdoor" | "any"
    public long arrivalTime;       // timestamp - for FIFO ordering
    public String status;          // "waiting" | "seated" | "cancelled"
    public String notes;

    public WaitingCustomer() {}

    public String getArrivalTimeFormatted() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTimeInMillis(arrivalTime);
        return String.format("%02d:%02d",
            cal.get(java.util.Calendar.HOUR_OF_DAY),
            cal.get(java.util.Calendar.MINUTE));
    }
}
