package com.tawlati.app.database;

import android.content.Context;
import androidx.room.*;
import androidx.sqlite.db.SupportSQLiteDatabase;
import com.tawlati.app.models.AppSettings;
import com.tawlati.app.models.TableModel;
import com.tawlati.app.models.WaitingCustomer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(
    entities = {TableModel.class, WaitingCustomer.class, AppSettings.class},
    version = 1,
    exportSchema = false
)
public abstract class TawlatiDatabase extends RoomDatabase {

    public abstract TableDao tableDao();
    public abstract WaitingListDao waitingListDao();
    public abstract SettingsDao settingsDao();

    private static volatile TawlatiDatabase INSTANCE;
    public static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(4);

    public static TawlatiDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (TawlatiDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                        context.getApplicationContext(),
                        TawlatiDatabase.class,
                        "tawlati_database"
                    )
                    .addCallback(new RoomDatabase.Callback() {
                        @Override
                        public void onCreate(@androidx.annotation.NonNull SupportSQLiteDatabase db) {
                            super.onCreate(db);
                            // Insert default settings on first run
                            databaseExecutor.execute(() -> {
                                AppSettings defaultSettings = new AppSettings();
                                INSTANCE.settingsDao().insert(defaultSettings);
                                // Generate default tables (20 indoor + 15 outdoor)
                                generateDefaultTables(20, 15);
                            });
                        }
                    })
                    .build();
                }
            }
        }
        return INSTANCE;
    }

    public static void generateDefaultTables(int indoorCount, int outdoorCount) {
        databaseExecutor.execute(() -> {
            INSTANCE.tableDao().deleteAll();
            java.util.List<TableModel> tables = new java.util.ArrayList<>();
            int counter = 1;
            for (int i = 0; i < indoorCount; i++) {
                TableModel t = new TableModel();
                t.tableNumber = String.format("T%02d", counter++);
                t.area = "indoor";
                t.capacity = 4;
                t.status = "available";
                tables.add(t);
            }
            for (int i = 0; i < outdoorCount; i++) {
                TableModel t = new TableModel();
                t.tableNumber = String.format("T%02d", counter++);
                t.area = "outdoor";
                t.capacity = 6;
                t.status = "available";
                tables.add(t);
            }
            INSTANCE.tableDao().insertAll(tables);
        });
    }
}
