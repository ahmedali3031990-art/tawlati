package com.tawlati.app.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.tawlati.app.R;
import com.tawlati.app.models.AppSettings;
import com.tawlati.app.viewmodels.MainViewModel;

public class SettingsActivity extends AppCompatActivity {

    private MainViewModel viewModel;
    private AppSettings currentSettings;

    private EditText etCafeName, etIndoorCount, etOutdoorCount,
                     etDefaultDuration, etAlertBefore, etNewPassword;
    private Switch switchDarkMode;
    private Button btnSave, btnResetTables;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Show password dialog first
        showPasswordDialog();
    }

    private void showPasswordDialog() {
        EditText etPassword = new EditText(this);
        etPassword.setHint("كلمة مرور المدير");
        etPassword.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        new AlertDialog.Builder(this)
            .setTitle("🔒 الدخول للإعدادات")
            .setMessage("يرجى إدخال كلمة مرور المدير")
            .setView(etPassword)
            .setPositiveButton("دخول", (dialog, which) -> {
                String password = etPassword.getText().toString();
                verifyPassword(password);
            })
            .setNegativeButton("إلغاء", (dialog, which) -> finish())
            .setCancelable(false)
            .show();
    }

    private void verifyPassword(String inputPassword) {
        new Thread(() -> {
            viewModel = new ViewModelProvider(this).get(MainViewModel.class);
            currentSettings = viewModel.getSettingsSync();

            String correctPassword = currentSettings != null ? currentSettings.adminPassword : "1234";
            boolean correct = correctPassword.equals(inputPassword);

            runOnUiThread(() -> {
                if (correct) {
                    setContentView(R.layout.activity_settings);
                    initViews();
                    populateSettings();
                } else {
                    Toast.makeText(this, "❌ كلمة المرور غير صحيحة", Toast.LENGTH_SHORT).show();
                    finish();
                }
            });
        }).start();
    }

    private void initViews() {
        etCafeName = findViewById(R.id.etCafeName);
        etIndoorCount = findViewById(R.id.etIndoorCount);
        etOutdoorCount = findViewById(R.id.etOutdoorCount);
        etDefaultDuration = findViewById(R.id.etDefaultDuration);
        etAlertBefore = findViewById(R.id.etAlertBefore);
        etNewPassword = findViewById(R.id.etNewPassword);
        switchDarkMode = findViewById(R.id.switchDarkMode);
        btnSave = findViewById(R.id.btnSaveSettings);
        btnResetTables = findViewById(R.id.btnResetTables);

        btnSave.setOnClickListener(v -> saveSettings());
        btnResetTables.setOnClickListener(v -> confirmResetTables());

        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());
    }

    private void populateSettings() {
        if (currentSettings == null) return;
        etCafeName.setText(currentSettings.cafeName);
        etIndoorCount.setText(String.valueOf(currentSettings.indoorTablesCount));
        etOutdoorCount.setText(String.valueOf(currentSettings.outdoorTablesCount));
        etDefaultDuration.setText(String.valueOf(currentSettings.defaultBookingDurationMin));
        etAlertBefore.setText(String.valueOf(currentSettings.alertBeforeMinutes));
        switchDarkMode.setChecked(currentSettings.darkMode);
    }

    private void saveSettings() {
        if (currentSettings == null) currentSettings = new AppSettings();

        String cafeName = etCafeName.getText().toString().trim();
        String indoorStr = etIndoorCount.getText().toString().trim();
        String outdoorStr = etOutdoorCount.getText().toString().trim();
        String durationStr = etDefaultDuration.getText().toString().trim();
        String alertStr = etAlertBefore.getText().toString().trim();
        String newPass = etNewPassword.getText().toString().trim();

        if (!TextUtils.isEmpty(cafeName)) currentSettings.cafeName = cafeName;
        if (!TextUtils.isEmpty(indoorStr)) currentSettings.indoorTablesCount = Integer.parseInt(indoorStr);
        if (!TextUtils.isEmpty(outdoorStr)) currentSettings.outdoorTablesCount = Integer.parseInt(outdoorStr);
        if (!TextUtils.isEmpty(durationStr)) currentSettings.defaultBookingDurationMin = Integer.parseInt(durationStr);
        if (!TextUtils.isEmpty(alertStr)) currentSettings.alertBeforeMinutes = Integer.parseInt(alertStr);
        if (!TextUtils.isEmpty(newPass)) currentSettings.adminPassword = newPass;
        currentSettings.darkMode = switchDarkMode.isChecked();

        viewModel.updateSettings(currentSettings);
        Toast.makeText(this, "✅ تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show();
    }

    private void confirmResetTables() {
        String indoorStr = etIndoorCount.getText().toString().trim();
        String outdoorStr = etOutdoorCount.getText().toString().trim();

        new AlertDialog.Builder(this)
            .setTitle("⚠️ تحديث الطاولات")
            .setMessage("سيتم إعادة توليد جميع الطاولات وفقاً للإعدادات الجديدة.\n" +
                        "سيتم مسح جميع الحجوزات الحالية. هل أنت متأكد؟")
            .setPositiveButton("نعم، تحديث", (dialog, which) -> {
                int indoor = TextUtils.isEmpty(indoorStr) ? 20 : Integer.parseInt(indoorStr);
                int outdoor = TextUtils.isEmpty(outdoorStr) ? 15 : Integer.parseInt(outdoorStr);
                saveSettings();
                viewModel.regenerateTables(indoor, outdoor);
                Toast.makeText(this, "✅ تم تحديث الطاولات", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }
}
